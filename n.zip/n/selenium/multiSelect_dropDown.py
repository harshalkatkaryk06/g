from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
import time

# Launch Chrome
driver = webdriver.Chrome()

# Open the website
driver.get("https://demoqa.com/select-menu")

# Locate the multi-select dropdown
multi_select_element = driver.find_element(By.ID, "cars")

# Create Select object
multi_select = Select(multi_select_element)

# ---------------------------------------
# Select by Visible Text
# ---------------------------------------
multi_select.select_by_visible_text("Volvo")
time.sleep(5)

# Deselect by Visible Text
multi_select.deselect_by_visible_text("Volvo")
time.sleep(5)

# ---------------------------------------
# Select by Index
# ---------------------------------------
multi_select.select_by_index(1)      # Saab
time.sleep(5)

# ---------------------------------------
# Select by Value
# ---------------------------------------
multi_select.select_by_value("audi") # Audi
time.sleep(5)

# ---------------------------------------
# Print all selected options
# ---------------------------------------
all_selected_opt_list = multi_select.all_selected_options

print("Selected Options:")
for opt in all_selected_opt_list:
    print(opt.text)

time.sleep(5)

# ---------------------------------------
# Deselect by Index
# ---------------------------------------
multi_select.deselect_by_index(0)
time.sleep(5)

# ---------------------------------------
# Deselect by Value
# ---------------------------------------
multi_select.deselect_by_value("audi")
time.sleep(5)

# ---------------------------------------
# Deselect All
# ---------------------------------------
multi_select.deselect_all()
time.sleep(5)

# Close browser
driver.quit()