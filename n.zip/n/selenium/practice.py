from selenium import webdriver
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
import time

driver = webdriver.Chrome()

driver.get('https://www.facebook.com/')
wait = WebDriverWait(driver, 20)

original_window = driver.current_window_handle

driver.switch_to.new_window('tab')
wait.until(EC.number_of_windows_to_be(2))
time.sleep(10)
driver.execute_script("window.open('https://www.google.com/')")
driver.execute_script("window.open('https://cwe.mitre.org/')")
wait.until(EC.number_of_windows_to_be(4))
time.sleep(10)
driver.quit()