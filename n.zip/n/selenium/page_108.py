from selenium import webdriver
import time

# WINDOWS OPERATIONS

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()

driver.get("https://www.facebook.com")

wait = WebDriverWait(driver, 10)

original_window = driver.current_window_handle

# Try:
# print(original_window, type(original_window))

driver.switch_to.new_window('tab')

wait.until(EC.number_of_windows_to_be(2))

driver.execute_script("window.open('http://www.google.com/');")
driver.execute_script("window.open('https://cwe.mitre.org/data/downloads.html');")
wait.until(EC.number_of_windows_to_be(4))

all_windows = driver.window_handles

# Try:
# print(all_windows, type(all_windows))
time.sleep(5)
for window in all_windows:
    if window != original_window:
        driver.switch_to.window(window)
        break

driver.quit()