"""
Q1: Selenium automation on Google homepage
Steps: open Google -> maximize -> find logo location/size ->
check clickable -> click it, else type "Not clickable" in search box
"""
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# 1. Open Google homepage
driver = webdriver.Chrome()
driver.get("https://www.google.com")

# 2. Maximize the window
driver.maximize_window()
time.sleep(2)   # wait for page to load

# 3. Find the Google logo (it is an SVG element)
logo = driver.find_element(By.CSS_SELECTOR, "svg")   # simple way to get the logo SVG

# Print location and size
location = logo.location
size = logo.size

print("=============================================")
print(f"Target Found  : <svg>")
print(f"Location      : X = {location['x']}, Y = {location['y']}")
print(f"Dimensions    : Width = {size['width']}px, Height = {size['height']}px")
print("=============================================")

# 4. Check if the logo is clickable
# Google logo is a static image (not inside an <a> tag that navigates)
try:
    # Try to click – if it is not clickable this will fail or do nothing useful
    logo.click()
    print("Result: Logo is clickable.")
except Exception:
    print("Result: Logo is NOT clickable (static image).")
    print("Action: Entering text into the search box...")

    # 5. Type "Not clickable" in the search box
    search_box = driver.find_element(By.NAME, "q")
    search_box.clear()
    search_box.send_keys("Not clickable")
    print("Successfully entered 'Not clickable' into search box.")

time.sleep(3)   # so you can see the result
driver.quit()