"""
Q3: Selenium automation on Amazon homepage
Steps: open Amazon -> maximize -> locate search textbox ->
fetch location/size -> check enabled -> enter text if enabled
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# 1. Open Amazon homepage
driver = webdriver.Chrome()
driver.get("https://www.amazon.in")   # or "https://www.amazon.com"

# 2. Maximize the window
driver.maximize_window()
time.sleep(2)   # wait for page to load

# 3. Locate the search textbox
search_box = driver.find_element(By.ID, "twotabsearchtextbox")

# 4. Fetch location and size
location = search_box.location
size = search_box.size

print("=============================================")
print(f"Target Element: <input> (ID: twotabsearchtextbox)")
print(f"Location      : X = {location['x']}, Y = {location['y']}")
print(f"Dimensions    : Width = {size['width']}px, Height = {size['height']}px")
print("=============================================")

# 5. Check if enabled and enter text
if search_box.is_enabled():
    print("Result: Search textbox is enabled.")
    print("Action: Entering search query...")
    search_box.clear()
    search_box.send_keys("Wireless Headphones")
    print("Successfully entered 'Wireless Headphones' into search box.")
else:
    print("Result: Search textbox is NOT enabled.")

time.sleep(3)   # so you can see the result
driver.quit()