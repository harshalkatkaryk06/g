"""
Q2: Selenium automation on Facebook homepage
Steps: open Facebook -> maximize -> find logo location/size ->
check displayed & enabled -> click it, else type "Logo not clickable" in email textbox
"""
from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# 1. Open Facebook homepage
driver = webdriver.Chrome()
driver.get("https://www.facebook.com")

# 2. Maximize the window
driver.maximize_window()
time.sleep(2)   # wait for page to load

# 3. Find the Facebook logo (it is an <img> element)
logo = driver.find_element(By.CSS_SELECTOR, "img")   # simple way to get the logo image

# Print location and size
location = logo.location
size = logo.size

print("=============================================")
print(f"Target Found  : <img>")
print(f"Location      : X = {location['x']}, Y = {location['y']}")
print(f"Dimensions    : Width = {size['width']}px, Height = {size['height']}px")
print("=============================================")

# 4. Check if the logo is displayed and enabled
if logo.is_displayed() and logo.is_enabled():
    print("Result: Logo is displayed and enabled.")
    try:
        logo.click()
        print("Action: Logo clicked successfully.")
    except Exception:
        print("Result: Logo is NOT clickable.")
        print("Action: Entering text into the email textbox...")
        email_box = driver.find_element(By.ID, "email")
        email_box.clear()
        email_box.send_keys("Logo not clickable")
        print("Successfully entered 'Logo not clickable' into email textbox.")
else:
    print("Result: Logo is NOT displayed or NOT enabled.")
    print("Action: Entering text into the email textbox...")
    email_box = driver.find_element(By.ID, "email")
    email_box.clear()
    email_box.send_keys("Logo not clickable")
    print("Successfully entered 'Logo not clickable' into email textbox.")

time.sleep(3)   # so you can see the result
driver.quit()