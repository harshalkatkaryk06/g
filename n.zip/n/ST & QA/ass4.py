"""
Q4: Selenium automation on YouTube homepage
Steps: open YouTube -> maximize -> locate logo -> fetch location/size ->
check displayed -> check enabled/clickable -> click it, else print message
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# 1. Open YouTube homepage
driver = webdriver.Chrome()
driver.get("https://www.youtube.com")

# 2. Maximize the window
driver.maximize_window()
time.sleep(3)   # wait for page to load

# 3. Locate the YouTube logo
logo = driver.find_element(By.ID, "logo")

# 4. Fetch location and size
location = logo.location
size = logo.size

print("=============================================")
print(f"Target Element: <ytd-topbar-logo-renderer> (ID: logo)")
print(f"Location      : X = {location['x']}, Y = {location['y']}")
print(f"Dimensions    : Width = {size['width']}px, Height = {size['height']}px")
print("=============================================")

# 5. Check displayed and enabled/clickable
is_displayed = logo.is_displayed()
is_enabled = logo.is_enabled()

print(f"Is Displayed  : {is_displayed}")
print(f"Is Enabled    : {is_enabled}")

if is_displayed and is_enabled:
    print("Result: Logo is displayed and clickable. Clicking now...")
    logo.click()
else:
    print("Result: Logo is NOT displayed or NOT clickable.")

time.sleep(3)   # so you can see the result
driver.quit()