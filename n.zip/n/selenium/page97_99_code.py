from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome()
driver.maximize_window()

driver.get("https://www.facebook.com/")

wait = WebDriverWait(driver, 15)

# Click Create New Account
create_account_button = wait.until(
    EC.element_to_be_clickable((By.LINK_TEXT, "Create new account"))
)

create_account_button.click()

# -----------------------------------------
# First Name
# -----------------------------------------

first_name = wait.until(
    EC.visibility_of_element_located(
        (
            By.XPATH,
            "//label[normalize-space()='First name']/preceding-sibling::input"
        )
    )
)

first_name.send_keys("YourName")

# -----------------------------------------
# Last Name
# -----------------------------------------

last_name = wait.until(
    EC.visibility_of_element_located(
        (
            By.XPATH,
            "//label[normalize-space()='Surname']/preceding-sibling::input"
        )
    )
)

last_name.send_keys("YourSurname")

# -----------------------------------------
# Mobile / Email
# -----------------------------------------

mobile_number = wait.until(
    EC.visibility_of_element_located(
        (
            By.XPATH,
            "//input[contains(@aria-label, 'Mobile number') or contains(@aria-label, 'email')]"
        )
    )
)

mobile_number.send_keys("1234567890")

# -----------------------------------------
# Password
# -----------------------------------------

password = wait.until(
    EC.visibility_of_element_located(
        (
            By.XPATH,
            "//input[@type='password']"
        )
    )
)

password.send_keys("SecurePassword123")

# -----------------------------------------
# Date of Birth
# -----------------------------------------

day = wait.until(
    EC.presence_of_element_located(
        (By.ID, "day")
    )
)

month = wait.until(
    EC.presence_of_element_located(
        (By.ID, "month")
    )
)

year = wait.until(
    EC.presence_of_element_located(
        (By.ID, "year")
    )
)

day.send_keys("6")
month.send_keys("Sep")
year.send_keys("1990")

# -----------------------------------------
# Gender
# -----------------------------------------

gender_male = wait.until(
    EC.element_to_be_clickable(
        (By.XPATH, "//label[normalize-space()='Male']")
    )
)

gender_male.click()

# -----------------------------------------
# Sign Up
# -----------------------------------------

sign_up_button = wait.until(
    EC.element_to_be_clickable(
        (By.XPATH, "//button[contains(text(), 'Sign Up')]")
    )
)

sign_up_button.click()

time.sleep(5)

driver.quit()