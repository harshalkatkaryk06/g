from selenium import webdriver
import time
# MULTI-SELECT DROPDOWN

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

driver = webdriver.Chrome()

driver.get("https://demoqa.com/select-menu")

multi_select_element = driver.find_element(
    By.ID, "cars"
)  # The ID for Standard multi select

multi_select = Select(multi_select_element)

multi_select.select_by_visible_text("Volvo")

# Add time.sleep(5)
time.sleep(5)
multi_select.deselect_by_visible_text("Volvo")

multi_select.select_by_index(1)         # Select "Saab" (index 1)

multi_select.select_by_value("audi")    # Select "Audi"

all_selected_opt_list = multi_select.all_selected_options

for opt in all_selected_opt_list:
    print(opt.text)

multi_select.deselect_by_index(0)

multi_select.deselect_by_value("audi")

multi_select.deselect_all()