"""
Write a Selenium program to demonstrate Implicit, 
Explicit, and Fluent Waits on Google, 
using an incorrect locator and handling the resulting exceptions.
"""


from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    NoSuchElementException,
    TimeoutException,
)

driver = webdriver.Chrome()

driver.get("https://www.google.com")

# ======================================================
# 1. Implicit Wait
# ======================================================

print("\n========== IMPLICIT WAIT ==========")

driver.implicitly_wait(10)

try:
    search_box = driver.find_element(By.NAME, "wrong")
    search_box.send_keys("Pune")
    print("Element found using Implicit Wait.")
except NoSuchElementException:
    print("Implicit Wait Failed!")
    print("Exception: NoSuchElementException")

# ======================================================
# 2. Explicit Wait
# ======================================================

print("\n========== EXPLICIT WAIT ==========")

wait = WebDriverWait(driver, 15)

try:
    search_box_explicit = wait.until(
        EC.presence_of_element_located((By.NAME, "wrong"))
    )
    search_box_explicit.send_keys("Maharashtra")
    print("Element found using Explicit Wait.")
except TimeoutException:
    print("Explicit Wait Failed!")
    print("Exception: TimeoutException")

# ======================================================
# 3. Fluent Wait
# ======================================================

print("\n========== FLUENT WAIT ==========")

polling_wait = WebDriverWait(
    driver,
    timeout=20,
    poll_frequency=3,
    ignored_exceptions=[NoSuchElementException]
)

try:
    search_box_polling = polling_wait.until(
        EC.visibility_of_element_located((By.NAME, "wrong"))
    )
    search_box_polling.send_keys("India")
    print("Element found using Fluent Wait.")
except TimeoutException:
    print("Fluent Wait Failed!")
    print("Exception: TimeoutException")

# ======================================================
# Close Browser
# ======================================================

driver.quit()

print("\nProgram Finished Successfully.")