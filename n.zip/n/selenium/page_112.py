from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# iFrames

driver = webdriver.Chrome()

driver.get("https://the-internet.herokuapp.com/iframe")

time.sleep(5)

# Switch to the iframe using frame ID
driver.switch_to.frame("mce_0_ifr")

print("Switched to iframe")

time.sleep(5)

# Homework: Try switch_to using iframe XPATH

iframe_body = driver.find_element(By.TAG_NAME, "body")

# Enter text into iframe
iframe_body.send_keys("India")

time.sleep(5)

# Switch back to the main document
driver.switch_to.default_content()

time.sleep(5)

# Verify you are outside iframe and on main document
main_header = driver.find_element(By.TAG_NAME, "h3")

print("Main Document Header:", main_header.text)

time.sleep(5)

driver.quit()