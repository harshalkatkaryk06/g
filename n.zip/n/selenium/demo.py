from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
import time

driver = webdriver.Chrome()
driver.get('https://www.google.com')
driver.maximize_window()
time.sleep(5)


driver.implicitly_wait(10)
searchBox = driver.find_element(By.NAME, "q")
searchBox.send_keys("Pune")
time.sleep(5)

wait = WebDriverWait(driver, 15)
searchBox_Explicit = wait.until(
    EC.presence_of_element_located((By.NAME, "q"))
)
searchBox_Explicit.send_keys(" Maharashtra")


polling_wait = WebDriverWait(
    driver, 20, poll_frequency=3, 
    ignored_exceptions=[Exception]
)

searchBox_polling = polling_wait.until(
    EC.presence_of_element_located((By.NAME, "q"))
)
searchBox_polling.send_keys(" India")
searchBox_polling.send_keys(Keys.ENTER)

time.sleep(5)
driver.quit()