"""
Q5: Selenium automation on Google homepage
Steps: open Google -> locate search textbox -> get X, Y coordinates ->
check displayed -> check enabled -> enter text if enabled, else print message
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# 1. Open Google homepage
driver = webdriver.Chrome()
driver.get("https://www.google.com")

# Maximize (optional but good practice)
driver.maximize_window()
time.sleep(2)   # wait for page to load

# 2. Locate the search textbox
search_box = driver.find_element(By.NAME, "q")

# 3. Get X, Y coordinates and size
location = search_box.location
size = search_box.size

print("=============================================")
print(f"Target Element: <textarea> (name='q')")
print(f"Coordinates   : X = {location['x']}, Y = {location['y']}")
print(f"Dimensions    : Width = {size['width']}px, Height = {size['height']}px")
print("=============================================")

# 4. Check displayed and enabled
is_displayed = search_box.is_displayed()
is_enabled = search_box.is_enabled()

print(f"Is Displayed  : {is_displayed}")
print(f"Is Enabled    : {is_enabled}")

# 5. Enter text if enabled, else print message
if is_displayed and is_enabled:
    print("Result: Search textbox is active and enabled.")
    print("Action: Entering search query...")
    search_box.clear()
    search_box.send_keys("Selenium Automation")
    print("Successfully entered text into Google search box.")
else:
    print("Result: Search textbox is NOT active or NOT enabled.")

time.sleep(3)   # so you can see the result
driver.quit()