"""
Q6: Selenium automation on Google homepage
Steps: open Google -> maximize -> locate logo -> fetch X, Y, width, height ->
take screenshot -> check displayed -> print result accordingly
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# 1. Open Google homepage
driver = webdriver.Chrome()
driver.get("https://www.google.com")

# 2. Maximize the window
driver.maximize_window()
time.sleep(2)   # wait for page to load

# 3. Locate the Google logo (SVG element)
logo = driver.find_element(By.CSS_SELECTOR, "svg")

# 4. Fetch X, Y, width, height
location = logo.location
size = logo.size

print("=============================================")
print(f"Target Element: <svg>")
print(f"Coordinates   : X = {location['x']}, Y = {location['y']}")
print(f"Dimensions    : Width = {size['width']}px, Height = {size['height']}px")
print("=============================================")

# 5. Take screenshot of the logo
logo.screenshot("google_logo_screenshot.png")
print("Screenshot successfully saved as 'google_logo_screenshot.png'.")

# 6. Check if displayed and print result
if logo.is_displayed():
    print("Result: Google logo is displayed on the page.")
else:
    print("Result: Google logo is NOT displayed on the page.")

time.sleep(2)
driver.quit()