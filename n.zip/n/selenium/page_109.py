from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# ALERTS

driver = webdriver.Chrome()

driver.get("https://the-internet.herokuapp.com/javascript_alerts")

time.sleep(5)

confirm_button = driver.find_element(
    By.XPATH,
    "//button[text()='Click for JS Confirm']"
)

confirm_button.click()

time.sleep(5)

alert = driver.switch_to.alert      # Switch to the alert

print("Alert text:", alert.text)

time.sleep(5)

alert.accept()                      # Try: alert.dismiss()

time.sleep(5)

result = driver.find_element(By.ID, "result")

print("Page result after accepting alert:", result.text)

time.sleep(5)

driver.quit()