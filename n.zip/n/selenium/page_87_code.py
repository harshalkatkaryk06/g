from selenium import webdriver
from selenium.webdriver.common.by import By
import time

# Launch Chrome browser
driver = webdriver.Chrome()

# Open the website
driver.get("https://the-internet.herokuapp.com/checkboxes")

# Locate the checkboxes
checkbox1 = driver.find_element(By.XPATH, "//form[@id='checkboxes']/input[1]")
checkbox2 = driver.find_element(By.XPATH, "//form[@id='checkboxes']/input[2]")

# Click Checkbox 1 (Check)
checkbox1.click()
time.sleep(5)

# Click Checkbox 1 again (Uncheck)
checkbox1.click()
time.sleep(5)

# Click Checkbox 2 (Uncheck)
checkbox2.click()
time.sleep(5)

# Click Checkbox 2 again (Check)
checkbox2.click()
time.sleep(5)

# If Checkbox 1 is not selected, select it
if not checkbox1.is_selected():
    checkbox1.click()

time.sleep(5)

# If Checkbox 1 is selected, unselect it
if checkbox1.is_selected():
    checkbox1.click()

time.sleep(5)

# Close the browser
driver.quit()