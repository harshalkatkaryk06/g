import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select

# Launch Chrome
driver = webdriver.Chrome()

# Open the website
driver.get("https://the-internet.herokuapp.com/dropdown")

# Locate the dropdown
mydropdown = driver.find_element(By.ID, "dropdown")

# Create Select object
dropdown = Select(mydropdown)

# -----------------------------
# Select by Visible Text
# -----------------------------
dropdown.select_by_visible_text("Option 1")
time.sleep(5)

# Print the selected option
selected_option = dropdown.first_selected_option
print(f"Selected option: {selected_option.text}")

# -----------------------------
# Select by Value
# -----------------------------
dropdown.select_by_value("2")     # Selects Option 2
time.sleep(5)

# -----------------------------
# Select by Index
# -----------------------------
# Index starts from 0
# 0 -> "Please select an option"
# 1 -> Option 1
# 2 -> Option 2
dropdown.select_by_index(1)
time.sleep(5)

# -----------------------------
# Deselect (Works only for Multi-Select)
# -----------------------------
# These lines will raise an exception because
# this dropdown is NOT a multi-select.

# dropdown.deselect_by_visible_text("Option 1")
# dropdown.deselect_all()

# Close browser
driver.quit()